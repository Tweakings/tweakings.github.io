(h, dt, bars, p, col, bcol){

var PPB = 33,
    maxBD = Math.ceil(h * 0.285),
    //maxBD = h * 0.285,
    minBD = 0,//maxBD * 0.2,
    deltaBD = maxBD - minBD,
    padding = maxBD * 0.24,
    edgeOffset = (maxBD * 0.3) + (padding * 0.5),
    halfHeight = h /2,
    lineWidth = maxBD * 0.1,
    width = maxBD * 3 + (padding *2) + (lineWidth *2)+ 1;

col = "rgb("+ col.join() + ")";
bcol = "rgba("+ bcol.join() +")";

//var canvas = document.getElementById("myCanvas");
var canvas = document.createElement("canvas");

var ctx = canvas.getContext("2d");

canvas.width = width;
canvas.height = h;



function sizeForBall(num){
    var used = (num-1) *33,
    remain = Math.max(0,Math.min(33, p - used));
    return Math.min(minBD + ((remain / PPB) * deltaBD),maxBD);
}
//ctx.fillStyle = "blue";
//ctx.fillRect(0,0,width,h);

/*
if (low) {col = "#FF3B30"; shadow = "rgba(255, 59, 48, 0.3)";}
if (charging){ col = "#0CF"; shadow= "rgba(0, 204, 255, 0.3)";}
if (p ==100) {col = "#4CD964"; shadow= "rgba(76, 217, 100, 0.3)";}
*/

var startX = width - Math.ceil(maxBD /2) - 1 - (lineWidth);


//var x = startX;

function moveToNextOrigin(v){
    return (v-(maxBD + padding));
}
function bX(n){
    return startX - ((maxBD + padding) * (n-1));
}
function bY(n){
    //var z = 1;
    //if (n % 2) z= -1;
    //z = halfh + z*edgeOffset;
    //return z;
    return halfHeight;
}
function toRad(y){
    return (Math.PI/180)*y;
}

function drawBallAt(n, x, y){
    ctx.moveTo(x + (sizeForBall(n)/2), y);
    ctx.arc(x, y,(sizeForBall(n)/2), 0, toRad(360));
}

function drawBall(n){

    drawBallAt(n, bX(n),bY(n));
}

function drawMaxBall(n){
    ctx.moveTo(bX(n) + maxBD/2, bY(n));
    ctx.arc(bX(n), bY(n), maxBD/2, 0, toRad(360));
}
function drawHalfBall(n){
    ctx.moveTo(bX(n) + maxBD/2, bY(n));
    ctx.arc(bX(n), bY(n), maxBD/2.8, 0, toRad(360));
}
function drawClipBall(n){
    ctx.moveTo((bX(n) + maxBD/2)-.2, bY(n));
    ctx.arc(bX(n), bY(n), (maxBD/2)-.2, 0, toRad(360));
}

//ctx.strokeStyle = col;



//if(p ==100 && charging) ctx.stroke();
//ctx.stroke();



ctx.strokeStyle = col;
ctx.fillStyle = col;
ctx.lineWidth = lineWidth;

ctx.beginPath();
//var dt = 5;

if (dt < 5){

if (dt>2) drawMaxBall(1); else drawHalfBall(1);
if (dt==4) drawHalfBall(2);
if (dt>2) drawMaxBall(3); else drawHalfBall(3);
ctx.fillStyle = col;
ctx.fill();

ctx.beginPath();
ctx.moveTo(bX(1),bY(1));
ctx.lineTo(bX(3),bY(3));
ctx.stroke();

}else if(dt==5){

var i = 3;


ctx.moveTo(bX(i),bY(i));
if(p<100){for(; i>1; i--){
    if(sizeForBall(i)<maxBD){
        if(i != 1) ctx.lineTo(bX(i-1),bY(i-1));
    }else break;
}}
ctx.strokeStyle=bcol;
ctx.stroke();

ctx.beginPath();
drawClipBall(1);
drawClipBall(2);
drawClipBall(3);
  //drawClipBall(4);
  //drawClipBall(5);


ctx.save();
ctx.clip();
ctx.clearRect(0,0,width,h);
ctx.restore();

ctx.beginPath();
if(p<100){for(i=1;i<4;i++){
  if(sizeForBall(i)<maxBD) drawMaxBall(i);
}}
//drawMaxBall(1);
//drawMaxBall(2);
//drawMaxBall(3);

ctx.fillStyle = bcol;
ctx.fill();


ctx.beginPath();

drawBall(1);
drawBall(2);
drawBall(3);
//drawBall(4);
//drawBall(5);

ctx.fillStyle = col;
ctx.fill();

ctx.beginPath();
ctx.moveTo(bX(1),bY(1));
if(sizeForBall(2)==maxBD) ctx.lineTo(bX(2),bY(2));
if(sizeForBall(3)==maxBD) ctx.lineTo(bX(3),bY(3));
ctx.strokeStyle=col;
ctx.stroke();
}

//drawMaxBall(4);
//drawMaxBall(5);

//ctx.fillStyle = "blue";
//ctx.fill();



//ctx.font = "bold " + 50 + "pt Helvetica";
//ctx.textAlign = "center";
//ctx.textBaseline = "middle";
//ctx.fillStyle = "rgba(155,20,190,1.0)";


//ctx.fillText(Number(sizeForBall(5)).toPrecision(3), width/2, halfHeight);

return canvas.toDataURL("image/png");
}

(height, level, main, base) {
    function t(a) {
        return 0 + Math.max(0, Math.min(20, w - 20 * (a - 1))) / 20 * x
    }

    function e(a) {
        return y - (c + u) * (a - 1)
    }

    function k(b) {
        var c = e(b),
            d = f;
        a.moveTo(c + t(b) / 2, d);
        a.arc(c, d, t(b) / 2, 0, Math.PI / 180 * 360)
    }

    function l(b) {
        a.moveTo(e(b) + c / 2, f);
        a.arc(e(b), f, c / 2, 0, Math.PI / 180 * 360)
    }

    function m(b) {
        a.moveTo(e(b) + c / 2 - .2, f);
        a.arc(e(b), f, c / 2 - .2, 0, Math.PI / 180 * 360)
    }
    var w = level;
    //low = "black";
    var c = .285 * height,
        x = c - 0,
        u = .3 * c,
        f = height / 2,
        b = .1 * c;
    var lpm = 5 * c + 4 * u + 2 * b;
    base = "rgba(" + base.join() + ")";
    //main.join();
    var low = "rgb(" + main.join() + ")";
    main = document.createElement("canvas");
    var a = main.getContext("2d");
    main.width = lpm;
    main.height = height;
    a.fillStyle = low;
    a.lineWidth = b;
    var y = lpm - Math.ceil(c / 2) - 1 - b,
        b = 5;
    for (a.moveTo(e(b), f); 1 < b; b--)
        if (t(b) < c) 1 != b && a.lineTo(e(b - 1), f);
        else break;
    a.strokeStyle = base;
    100 > level && a.stroke();
    a.beginPath();
    for (a.moveTo(e(b), f); 1 < b; b--) 1 != b && a.lineTo(e(b - 1), f);
    a.strokeStyle = low;
    //100 == level && charge ||
    a.stroke();
    a.beginPath();
    m(1);
    m(2);
    m(3);
    m(4);
    m(5);
    a.save();
    a.clip();
    a.clearRect(0, 0, lpm, height);
    a.restore();
    a.beginPath();
    l(1);
    l(2);
    l(3);
    l(4);
    l(5);
    a.fillStyle = base;
    a.fill();
    a.beginPath();
    k(1);
    k(2);
    k(3);
    k(4);
    k(5);
    a.fillStyle = low;
    a.fill();
    //a.font = "bold 50pt Helvetica";
    //a.textAlign = "center";
    //a.textBaseline = "middle";
    //a.fillStyle = "rgba(155,20,190,1.0)";
    return main.toDataURL("image/png")
}
